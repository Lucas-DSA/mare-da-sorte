const products = [
  { id: 1, name: "Acara Severum Red Spot 8cm", category: "jumbo", price: 45.90, stock: 5 },
  { id: 2, name: "Acara severum gold", category: "jumbo", price: 39.90, stock: 3 },
  { id: 3, name: "Ciclídeo Azul Elétrico", category: "ciclideos", price: 29.90, stock: 4 },
];

let cart = JSON.parse(localStorage.getItem("cart")) || [];

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function loadProducts(category = "all", searchTerm = "") {
  const container = document.getElementById("products-container");
  container.innerHTML = "";

  const filtered = products.filter(p => {
    const matchesCategory = category === "all" || p.category === category;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  filtered.forEach(p => {
    const item = document.createElement("div");
    item.className = "product-item";
    item.innerHTML = \`
      <h3>\${p.name}</h3>
      <p>R$ \${p.price.toFixed(2)}</p>
      <p>Estoque: \${p.stock}</p>
      <button class="add-to-cart" data-id="\${p.id}" \${p.stock === 0 ? "disabled" : ""}>Adicionar</button>
    \`;
    container.appendChild(item);
  });

  document.querySelectorAll(".add-to-cart").forEach(btn => {
    btn.addEventListener("click", addToCart);
  });
}

function addToCart(event) {
  const id = parseInt(event.target.dataset.id);
  const product = products.find(p => p.id === id);

  if (product.stock > 0) {
    cart.push(product);
    product.stock--;
    updateCartCount();
    saveCart();
    loadProducts(document.querySelector(".filter-btn.active").dataset.category, document.getElementById("search-input").value);
    alert(\`\${product.name} adicionado ao carrinho!\`);
  } else {
    alert("Produto esgotado!");
  }
}

function updateCartCount() {
  document.getElementById("cart-count").textContent = cart.length;
}

document.querySelectorAll(".filter-btn").forEach(button => {
  button.addEventListener("click", function () {
    document.querySelectorAll(".filter-btn").forEach(btn => btn.classList.remove("active"));
    this.classList.add("active");
    loadProducts(this.dataset.category, document.getElementById("search-input").value);
  });
});

document.getElementById("search-input").addEventListener("input", function() {
  const category = document.querySelector(".filter-btn.active").dataset.category;
  loadProducts(category, this.value);
});

function updateTime() {
  const now = new Date();
  const hour = now.getHours();
  const minutes = now.getMinutes().toString().padStart(2, '0');
  document.getElementById("current-time").textContent = \`\${hour}:\${minutes}\`;
}

updateCartCount();
loadProducts();
updateTime();
setInterval(updateTime, 60000);

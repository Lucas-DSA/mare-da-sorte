const products = [{ id: 1, name: "Peixe Dourado", price: 29.90 }];
let cart = [];

function loadProducts() {
  const container = document.getElementById("products-container");
  products.forEach(p => {
    const el = document.createElement("div");
    el.className = "product-item";
    el.innerHTML = `<h3>${p.name}</h3><p>R$ ${p.price.toFixed(2)}</p><button onclick="addToCart(${p.id})">Adicionar</button>`;
    container.appendChild(el);
  });
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCartCount();
}

function updateCartCount() {
  document.getElementById("cart-count").textContent = cart.length;
}

async function calculateFreight() {
  const cep = document.getElementById("address-input").value;
  const res = await fetch("http://localhost:3000/frete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cepDestino: cep })
  });
  const data = await res.json();
  return parseFloat(data.Valor.replace(",", "."));
}

async function renderCart() {
  const list = document.getElementById("cart-items");
  list.innerHTML = "";
  let total = cart.reduce((sum, p) => sum + p.price, 0);
  let freight = await calculateFreight();
  cart.forEach((item, i) => {
    const li = document.createElement("li");
    li.innerText = `${item.name} - R$ ${item.price.toFixed(2)}`;
    list.appendChild(li);
  });
  document.getElementById("freight-total").textContent = `R$ ${freight.toFixed(2)}`;
  document.getElementById("cart-total").textContent = `R$ ${(total + freight).toFixed(2)}`;
  document.getElementById("cart-modal").classList.remove("hidden");
}

document.querySelector(".cart-icon").addEventListener("click", renderCart);
document.getElementById("close-cart").addEventListener("click", () => {
  document.getElementById("cart-modal").classList.add("hidden");
});

loadProducts();